﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assigment2RestServices.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Assigment2RestServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        //1.This is our Book List
        private static List<Book> cList = new List<Book>();
        //2.We call this method to return the customer List
        public BookController()
        {
            cList = BookList.books;
        }
        // GET: api/<BookController>
        [HttpGet]
        public List<Book> Get()
        {
            return cList;
        }

        // GET api/<BookController>/5
        [HttpGet("{isbn}")]
        public IActionResult Get(string isbn)
        {
            var book = GetBook(isbn);
            if (book == null)
            {
                return NotFound(new { message = "Isbn not found" });
            }
            return Ok(book);
        }

        private Book GetBook(string isbn)
        {
            var book = cList.FirstOrDefault(e => e.Isbn == isbn);
            return book;
        }

        // POST api/<BookController>
        [HttpPost]
        public IActionResult Post([FromBody] Book book)
        {
            cList.Add(book);
            return CreatedAtAction("Get", new { isbn = book.Isbn }, book);
        }

        // PUT api/<BookController>/5
        [HttpPut("{isbn}")]
        public IActionResult Put(string isbn, [FromBody] Book newbook)
        {
            if (isbn != newbook.Isbn)
            {
                return BadRequest();
            }
            var currentBook = GetBook(isbn);

            if (currentBook != null)
            {
                currentBook.Author = newbook.Author;
                currentBook.Title = newbook.Title;
                currentBook.PageNumber = newbook.PageNumber;
            }
            else
            {
                return NotFound();
            }
            return NoContent();
        }
            // DELETE api/<BookController>/5
            [HttpDelete("{isbn}")]
            public IActionResult Delete(string isbn)
            {
                Book b = GetBook(isbn);

                if (b != null)
                {
                    cList.Remove(b);
                }
                else
                {
                    NotFound();
                }
                return Ok(b);
            }

        }

    } 
