﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assigment2RestServices.Model
{
    public class Book
    {
    /// <summary>
    /// Instance field of class Book
    /// </summary>
        private string _title;
        private string _author;
        private int _pagenumber;
        private string _isbn;

        /// <summary>
        /// Default Constructor of class Book
        /// </summary>
        public Book()
        {

        }
        /// <summary>
        /// Constructor of Book class taking 4 parametres
        /// </summary>
        /// <param name="title"></param>
        /// <param name="author"></param>
        /// <param name="pagenumber"></param>
        /// <param name="isbn"></param>
        public Book(string title, string author, int pagenumber, string isbn)
        {
            Title = title;
            Author = author;
            PageNumber = pagenumber;
            Isbn = isbn;
        }

        /// <summary>
        /// Property title minimum 2 characters long
        /// </summary>
        public string Title
        {
            get { return _title; }
            set
            {
                if (value.Length < 2)
                {
                    throw new ArgumentException("The Title is not in right format, please try again");
                }
                _title = value;
            }
        }

        /// <summary>
        /// Property Author
        /// </summary>

        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }

        /// <summary>
        /// Property page number 10 < pagenumber <= 1000
        /// </summary>

        public int PageNumber
        {
            get { return _pagenumber; }
            set
            {
                if (value < 10 && value >= 1000)
                {
                    throw new ArgumentException("The Page number is not in right format, please try again");
                }
                _pagenumber = value;
            }
        }

        /// <summary>
        /// Property Isbn needs to have exactly 13 characters
        /// </summary>
        public string Isbn
        {
            get { return _isbn; }
            set
            {
                if (value.Length != 13)
                {
                    throw new ArgumentException("The Isbn should have 13 characters, please try it again");
                }
                _isbn = value;
            }
        }

    }
}
