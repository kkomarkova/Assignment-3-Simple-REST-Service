﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assigment2RestServices.Model
{
    public class BookList
    {
        public static List<Book> books = new List<Book>()
        {
            new Book("Great Gatsby","Fitzerald", 208, "9780743273565"),
            new Book("Little Prince", "Exupery",96,"978-0156012195"),
            new Book("Up the Faraway Tree", "Blyton",88, "978-1405272247")
        };
    }
}
